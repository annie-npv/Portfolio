# MODIFIED VERSION OF KROSS HUGO THEME

- __Designed for Data Scientists__ that wish to create and showcase project portfolios
- __Integrates with Blogdown__, an R package for generating websites

![Example Portfolio - Kross](images/example_portfolio_kross.gif)
