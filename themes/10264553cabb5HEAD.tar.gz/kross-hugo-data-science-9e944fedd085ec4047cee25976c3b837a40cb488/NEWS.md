# kross_hugo_data_science 0.0.1.9000 (Development Version)

* Added github logo / social icon


# kross_hugo_data_science 0.0.1

* Updated the kross theme for a data science portfolio
* Added a `NEWS.md` file to track changes to the package.
